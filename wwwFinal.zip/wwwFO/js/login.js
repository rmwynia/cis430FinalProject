/**
 * Login.js
 */
 
"use strict"



var myUsernameElem; // instance variables for local storage
var mypasswordElem;

var mysqlUsernameSetting;
var mysqlPasswordSetting;


document.addEventListener("deviceready", onDeviceReady, false); // event listener for login page

function onDeviceReady() {

	alert("onDeviceReady!!");
	
    myUsernameElem  = document.getElementById('usernameInputid'); // gets text element from form
    myPasswordElem  = document.getElementById('pwordInputid');    
    loadSettings();

    
	
}

function loadSettings() {
    myUsernameElem.value  = localStorage.mysqlUsernameSetting || 'mbrandt2'; // sets local storage variables
    myPasswordElem.value  = localStorage.mysqlPasswordSetting || 'codingKids';
    
}


function getPword(id){
		return (document.getElementById("pwordInputid").value); // grabs element from form for use in sql query
	}
function getUsername(id){
		return (document.getElementById("usernameInputid").value); // same for username
		
	}


	
function test(){
	console.log(password) // sends values to console for data validation
	console.log(username) 

	
	

		MySql.Execute(
			"dmazzola.com",					// mySQL server
			"mbrandt2", 						// login name
			"mbra1200", 					// login password
			"test_db_mbrandt2", 			// database to use
											// SQL query string
			"SELECT 											\
				* 												\
			 FROM 												\
				SafetyPin 										\
			 													\
															 	\
			 													\
			 LIMIT 10;",

		function processQueryResult(queryReturned) {
    		if (!queryReturned.Success) {
    			alert(queryReturned.Error)
    		} else {
    			

    			for (var i =0; i < queryReturned.Result.length; i++) {   // loops through query result

					var str = JSON.stringify(queryReturned.Result[i].username, null, 2); // stores username as string
    				console.log(str);
    				var str2 = JSON.stringify(queryReturned.Result[i].password, null, 2);
    				console.log(str2);
    				var n = str.includes(username); // bool to see if includes text element from form
    				var y = str2.includes(password);
    				
    				  					
    				
    				console.log(n); // logging to the console for data validation
    				console.log(y);

    				document.getElementById('Purple').style.display="hidden";//forces page load on click
					if (n == true && y == true)
					{
						alert("It worked!") // alert to let user know that login worked
						document.getElementById('Purple').style.display="hidden";
					}
					else {
						console.log("it didnt work");
					}


    				
    			}
    		}
    	}
    	
	    );}