"use strict;"

function fillTable() {
	
	var table =document.getElementById("conversation");
	//chat back variables
	
	//user input variables
	var row= table.insertRow(0);
	var rowA=table.insertRow(1);
	var cell1 =row.insertCell(0);
	var cell2 =row.insertCell(1);
	//chat back variables
	var cell3 =rowA.insertCell(0);
	var cell4 =rowA.insertCell(1);

	var cell5=rowA.insertCell(2);
	var cell6=row.insertCell(2)
;	
	var string;
	var i= document.getElementById("conversation").rows.length;
	

	
	var d = new Date();

	//finding out the hours and the minutes 
	var h= d.getHours();
	var s = d.getMinutes();
	var currentTime =h +":"+ s;


	//inserting the user input and the date and the time into the table. 
	if (document.getElementById("chatInput").value!= "")
	{
	if (i==3)
	{
		cell1.innerHTML=currentTime + " "+ "Taylor";
		cell2.innerHTML = "Hey Peeps";

	}
	if (i==5)
	{
		cell1.innerHTML=currentTime + " "+ "Katie";
		cell2.innerHTML = "What Up Guys";
	}

	if(i==7)
	{
		cell1.innerHTML=currentTime + " "+ "Maddie";
		cell2.innerHTML = "I am at Casa! Where are YOU?!";

	}

	if(i==9)
	{
		cell1.innerHTML=currentTime+ " "+ "Bozhi";
		cell2.innerHTML = "Check Out the Map!";
	}
	cell4.innerHTML = document.getElementById("chatInput").value;
	cell3.innerHTML= currentTime + " "+ "Rachel";

}

reset();
	//cell4.innerHTML=i;
	



	return false;
}
function showHomeTab() {
			document.getElementById('home').click();
		}

		function showTab(event, tabName) {
		    // Declare all variables
		    var i, tabContentElems, tabLinkElems;

		    // Get all elements with class="tabContent" and hide them
		    tabContentElems = document.getElementsByClassName("tabContent");
		    for (i = 0; i < tabContentElems.length; i++) {
		        tabContentElems[i].style.display = "none";
		    }

		    // Get all elements with class="tabLink" and remove class "active"
		    tabLinkElems = document.getElementsByClassName("tabLink");
		    for (i = 0; i < tabLinkElems.length; i++) {
		        tabLinkElems[i].className = 
		        	tabLinkElems[i].className.replace(" active", "");
		    }

		    // Show the current tab, and add an "active" class to the link
		    document.getElementById(tabName).style.display = "block";
		    event.currentTarget.className += " active";
		}	

function initMap() {

        var map = new google.maps.Map(document.getElementById('mapDiv'), {
          zoom: 18, /*map zooms 18*/
          center: {lat: 33.4241358, lng: -111.9402237} /* the map will automatically focus on the specified latitude and longitude*/
        });

        // Create an array of alphabetical characters used to label the markers.
        var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        // Add some markers to the map.
        // Note: The code uses the JavaScript Array.prototype.map() method to
        // create an array of markers based on a given "locations" array.
      
        var markers = locations.map(function(location, i) {
          return new google.maps.Marker({
            position: location,
            label: labels[i % labels.length]
          });
        });

        // Add a marker clusterer to manage the markers.
        var markerCluster = new MarkerClusterer(map, markers,
            {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
      }
      var locations = [
        {lat: 33.4241358, lng: -111.9402237},
        {lat: 33.4243221, lng: -111.9398831},
        {lat: 33.424258 , lng: -111.939827 },
        {lat: 33.424252 , lng: -111.939827 },
        {lat: 33.423995 , lng: -111.939788 }


        
      ]
 

  function reset(){
